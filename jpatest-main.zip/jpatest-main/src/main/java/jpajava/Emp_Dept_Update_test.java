package jpajava;

import domain.Department;
import domain.Employee;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;

public class Emp_Dept_Update_test {
  public static void main(String[] args) {
    EntityManagerFactory emf = Persistence.createEntityManagerFactory("jpatest");
    EntityManager em = emf.createEntityManager();
    EntityTransaction tx = em.getTransaction();

    tx.begin();
    System.out.println("트랜잭션 시작");
    try {
      Department dept = new Department();//비영속상태
      dept.setDeptName("IT------new");
      em.persist(dept);//영속상태
      System.out.println("dept생성");

      Department emp = em.find(Department.class, "202402");
      System.out.println("emp- db에서 가져옴");
      emp.setDeptName(dept);

      em.persist(emp);


      System.out.println("커밋 전");
      tx.commit();
      System.out.println("커밋 후");
    } catch (Exception e) {
      tx.rollback();
    }
    System.out.println("트랜잭션 종료");
  }
}



